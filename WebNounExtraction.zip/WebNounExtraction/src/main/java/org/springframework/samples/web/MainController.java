package org.springframework.samples.web;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class MainController {
	@RequestMapping(value = "/extract_nouns", method = RequestMethod.POST)
    String extract(@RequestParam("text") String text, Model model) {
		System.out.println("ege");
		
    	String[] nouns_array = NounExtractor.extract(text);
    	String nouns = Arrays.stream(nouns_array).collect(Collectors.joining("\n"));
    	model.addAttribute("text", text );
    	model.addAttribute("nouns", nouns);
		return "/index";
    }
}
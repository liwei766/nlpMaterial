package org.springframework.samples.web;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.atilika.kuromoji.TokenizerBase.Mode;
import com.atilika.kuromoji.ipadic.Token;
import com.atilika.kuromoji.ipadic.Tokenizer;
import com.atilika.kuromoji.ipadic.Tokenizer.Builder;


public class NounExtractor {
	public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) 
	{
	    Map<Object, Boolean> map = new ConcurrentHashMap<>();
	    return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}
	
	public static String[] extract(String text) {
		Tokenizer tokenizer = new Tokenizer();
		List<Token> tokens = tokenizer.tokenize(text);
		
		List<String> ng_part_of_speech = Arrays.asList("引用文字列", "動詞非自立的", "接続詞的", "人名", "形容動詞語幹", "助動詞語幹", "特殊", "接尾副詞可能", "代名詞", "非自立");
		
		List<Token> noun_tokens = tokens.stream()
				.filter(distinctByKey(token -> token.getSurface()))
			    .filter(token -> {
			    		String pos1 = token.getPartOfSpeechLevel1();
			    		String pos_detail = token.getPartOfSpeechLevel2() + "," + token.getPartOfSpeechLevel3() + "," + token.getPartOfSpeechLevel4();
//			    		return true;
			    		if(ng_part_of_speech.stream().anyMatch(ng -> (pos1 + pos_detail).contains(ng))) return false;
			    		return Arrays.asList(pos1.split(",", 0)).contains("名詞");
			    	})
			    .collect(Collectors.toList());
		
		return noun_tokens.stream().map(noun_token -> noun_token.getSurface()).toArray(String[]::new);
	}
}
